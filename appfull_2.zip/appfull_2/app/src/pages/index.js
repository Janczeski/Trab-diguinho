import React from "react"
import TasksList from "../components/tasks-list";
import { Link } from "gatsby";
import isPrivateRoute from "../components/private-route";
import IndexStyle from './index.module.css';
import Global from './global.css';
import HeaderPerfil from '../components/header_perfil';

class Index extends React.Component {
  render(){
    return (
      <div className={IndexStyle.div_pai}>
        <HeaderPerfil />
        <h1 className={IndexStyle.titulo}>Tarefas</h1>
        <TasksList/>
        <Link className={IndexStyle.link} to="/create-task">Criar uma tarefa</Link>
      </div>
    );
  }
}

export default isPrivateRoute({component: Index, location: '/'});