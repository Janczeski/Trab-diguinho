import React from 'react';
import TaskForm from '../components/task-form';
import isPrivateRoute from '../components/private-route';
import Global from './global.css';
import createTaskStyle from './create_task.module.css';
import HeaderPerfil from '../components/header_perfil';

class CreateTask extends React.Component {
  render() {
    return (
      <div>
      	<HeaderPerfil />
        <h1 className={createTaskStyle.mensagem}>Criar uma tarefa</h1>
        <TaskForm />
      </div>
    )
  }
}

export default isPrivateRoute({component: CreateTask, location: '/create-task'});