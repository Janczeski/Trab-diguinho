import React from 'react'; 
import HeaderStyle from './header_perfil.module.css'
import LogoutButton from  "../components/logout-button";

export default class HeaderPerfil extends React.Component {
	render(){
		return (

			<div className={HeaderStyle.pai}>

				<h1 className={HeaderStyle.branding}>WebMesada</h1>

				<ul className={HeaderStyle.menu}>
					<LogoutButton />
				</ul>

			</div>

		)
	}
}