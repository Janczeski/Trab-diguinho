import React from 'react';
import TaskModel from './models/task-model';
import UserModel from './models/user-model';
import Message from './message';
import {navigate} from 'gatsby';
import TaskStyle from './task.module.css';

class Task extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      task: {...props.data},
      valor_tarefa: 0
    };
    this.handleChangeAdc = this.handleChangeAdc.bind(this);
    this.handleChangeSub = this.handleChangeSub.bind(this);
    this.handleChangeValor = this.handleChangeValor.bind(this);
    this.onDimiss = this.onDimiss.bind(this);
  }

  onDimiss() {
    this.setState({...this.state, visible: !this.state.visible});
  }

  async _updateTask () {
    try {
      let task = {...this.state.task};
      delete task.user;
      delete task.created_date;
      let res = await TaskModel.updateWallet(this.state.task.id, task);
      return res.message;
    }catch(e) {
      return e.message;
    }
  }

  async handleChangeValor(e) {
    let newState = {...this.state};
    newState.valor_total = e.target.value;
    this.setState(newState);
  }

  async handleChangeAdc(e) {
    let newState = {...this.state};
    newState.task['valor_total'] += +this.state.task.valor_tarefa;
    await this.setState(newState);
    newState.message = await this._updateTask();
  }
  async handleChangeSub(e) {
    let newState = {...this.state};
    newState.task['valor_total'] -= +this.state.task.valor_tarefa;
    await this.setState(newState);
    newState.message = await this._updateTask();
  }

  

  render() {
    let date = new Date(this.state.task.created_date*1000);
    return (
      <div>
        <p>
          <p className={TaskStyle.descricao}>{this.state.task.descricao_tarefa}</p>
          <p className={TaskStyle.valortotal}>Valor Total: {this.state.task.valor_total}</p>
          <p className={TaskStyle.botao} onClick={this.handleChangeAdc}>+{this.state.task.valor_tarefa}</p>
          <p className={TaskStyle.botao} onClick={this.handleChangeSub}>-{this.state.task.valor_tarefa}</p>
        </p>
      </div>
    );
  }
}

export default Task;