import Model from './model'  //

class TaskModel extends Model{
  constructor() {
    super();
    this.serviceURL = 'http://localhost:3000';
    this.serviceName = 'task';
  }

  async list () {
    let url = this.serviceURL+'/'+this.serviceName+'s';
    return this.request.without.body(url);
  }

  async updateWallet (id, task) {
    let url = `${this.serviceURL}/${this.serviceName}/wallet/${id}`;
    return this.request.with.body(url, 'PUT', task);
  }
  
}

export default new TaskModel();