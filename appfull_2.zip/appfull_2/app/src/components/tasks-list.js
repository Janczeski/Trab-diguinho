import React from 'react'
import withDataSourceFetch from './data-source-fetch';
import TaskModel from './models/task-model';
import {Link} from 'gatsby';
import Message from './message';
import Task from './task';
import TaskListStyle from './tasklist.module.css';

const TasksList = (props) => {
  return (
    <div>
      <Message message={props.message} />
      {
        props.isFetching ? 'Buscando Tarefas' : 
        <ul>
          {
            props.data.map((task) => {
                return (<li>
                  <Task data={task} />
                 <p>
                    <button className={TaskListStyle.botaozao} onClick={props.remove} id={task.id}>Remover Tarefa</button>
                  </p>
                </li>);
              }
            )
          }
        </ul>
      }
    </div>
  )
};

export default withDataSourceFetch(TasksList, TaskModel.list.bind(TaskModel), TaskModel.delete.bind(TaskModel));