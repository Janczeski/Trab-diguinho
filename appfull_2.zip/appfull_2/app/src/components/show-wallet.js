import React from 'react'; 
import {navigate} from 'gatsby';
import UserModel from './models/user-model';

export default class ShowWallet extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            user: {...props.data}
        };
        this.showWallet = this.showWallet.bind(this); 
    }

    async showWallet(){
        // let usuario = UserModel.find(this.state.user.id);
        let user = {...this.state.user};
        console.log(this.state.user['name'])
    }

	render(){
		return (

            <div>
                <p onClick={this.showWallet}>aa</p>
            </div>

		)
	}
}