import React from 'react';
import { logout } from '../helpers/user-helper';
import { navigate } from 'gatsby';
import LogoutStyle from './logout.module.css';

export default class LogoutButton extends React.Component {
  constructor(props) {
    super(props);
    this.logout = this.logout.bind(this);
  }

  logout() {
    logout(navigate);
  }

  render() {
    return (
      <p>
        <p className={LogoutStyle.botao} onClick={this.logout}>Logout</p>
      </p>
    );
  }
}