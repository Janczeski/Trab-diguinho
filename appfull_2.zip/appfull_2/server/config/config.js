module.exports = {
  database_user: 'root',
  database_password: 'ifmaker1',
  database_name: 'task',
  jwtSecret: "MyS3cr3tK3Y",
  jwtSession: {session: false}
}