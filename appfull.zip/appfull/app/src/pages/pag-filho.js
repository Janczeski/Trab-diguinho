import React from "react"
import TasksList from "../components/tasks-list";
import { Link } from "gatsby";
import isPrivateRoute from "../components/private-route";
import LogoutButton from  "../components/logout-button";

class pag_filho extends React.Component {
  render(){
    return (
      <div>
        <h1>Atividades</h1>
        <div>
          <h2> Carteira</h2>
        </div>
        <h2>Registro de Atividades</h2>
        <button onClick={this.mostraratividades}>Mostrar Todas Atividades</button>
        <LogoutButton />
      </div>
    );
  }
  async mostraratividades(){
   alert("AAAAAA")
  }
}

export default isPrivateRoute({component: pag_filho, location: '/pag_filho'});